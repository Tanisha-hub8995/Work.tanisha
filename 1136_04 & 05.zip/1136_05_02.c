#include<stdio.h>

int main(){
int n,coef=1;
 printf("Enter the number of lines for Pascal's Triangle:");
 scanf("%d",&n);

  for(int i=0;i<n;i++){
      //printing spaces
      for(int space=1;space<=n-1;space++){
        printf("");
       }
         for(int j=0;j<=i;j++){
            //Calculate the coef
        if(j==0||i==0)
          coef=1;
        else
        coef = coef*(i-j+1)/j;

         //printing coef
         printf("%d",coef);

       }
        printf("\n");
     
    }
     return o;

  }















