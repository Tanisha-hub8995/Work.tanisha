#include<stdio.h>
int main(){
    int a,b,c,d;
    float f,g,h;
    printf("Give your choice:-\n 1)Addition\n2)Substraction\n3)Multiplication\n4)Divition\n");
    scanf("%d",&a);
    if (a==1)
   {printf("Give the numbers");
   scanf("%d%d",&b&c);
   d=b+c;
   printf("%d+%d=%d",b,c,d);
   }
  else if(a==2)
  {printf("Give the numbers");
  scanf("%d%d",&b&c);
  d=b-c;
  printf("%d-%d=%d",b,c,d);
  }
  else if(a==3)
  {printf("Give the numbers");
  scanf("%d%d",&b&c);
  d=b*c;
  printf("%d*%d=%d",b,c,d);
  }
  else if(a==4)
  {printf("Give the numbres");
  scanf("%d%d",&b&c);
  d=b/c;
  printf("%d/%d=%d",b,c,d); 
  }
  else{
   printf("Wrong choice"); 
  }
  return 0;
}















