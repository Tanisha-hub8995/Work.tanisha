#include<stdio.h>
int main(){
    int marks;
     printf("Enter the marks (out of 40):");
     scanf("%d",&marks);
      if(marks>=32&& marks<=40){
        printf("Grade A\n");
      }
      else if(marks>=24&& marks<=31){
        printf("Grade B\n");
      }
      else if(marks>=16&& marks<=23);{
        printf("Grade C\n");

      }
      else if(marks>=0&& marks<=15);{
        printf("Grade F\n");

      }
      else{
        printf("wrong input.marks should be between 0 to 40.\n");

      }
        
return 0;
    
}
      

