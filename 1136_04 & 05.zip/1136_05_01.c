#include<stdio.h>
int main(){
int lines =1,i=1;
printf("please enter the number of lines:");
scanf("%d",&lines);

while(i<=lines){
    int space=lines-1;
    int j=1;

    //printing spaces 
    while(space>0){\n
         printf("");
         space--;
  }
    //printing stars 
         int stars=0;
     do{
      printf("*")
      stars++:
    }  while (stars<i;)

     printf("\n");
     i++;
}    
   return 0;
}

  
    
     
  

















